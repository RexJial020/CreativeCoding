let gameState = 'title'; // Tracks the current state of the game (title, play, win, lose)
let spaceship; // The player's spaceship
let asteroids = []; // Array to store asteroids
let bullets = []; // Array to store bullets
let health = 100; // Player's health
let numAsteroids = 10; // Number of asteroids in the game
let score = 0; // Player's score
let ammo = 50; // Player's ammo
let particles = []; // Array to store particles

function setup() {
  createCanvas(800, 600); // Set up canvas size
  spaceship = new Spaceship(); // Initialize the spaceship
  for (let i = 0; i < numAsteroids; i++) {
    asteroids.push(new Asteroid()); // Create initial asteroids
  }
}

function draw() {
  background(0); // Clear the background

  // Check the current game state and call the appropriate function
  if (gameState === 'title') {
    drawTitleScreen();
  } else if (gameState === 'play') {
    playGame();
  } else if (gameState === 'win') {
    drawWinScreen();
  } else if (gameState === 'lose') {
    drawLoseScreen();
  }

  // Display and update particles
  for (let i = particles.length - 1; i >= 0; i--) {
    particles[i].display();
    particles[i].update();
    if (particles[i].finished()) {
      particles.splice(i, 1);
    }
  }
}

// Draw the title screen
function drawTitleScreen() {
  fill(255);
  textSize(32);
  textAlign(CENTER, CENTER);
  text('Space Shooter', width / 2, height / 2 - 20);
  textSize(24);
  text('Click to Start', width / 2, height / 2 + 20);
}

// Draw the win screen
function drawWinScreen() {
  fill(255);
  textSize(32);
  textAlign(CENTER, CENTER);
  text('You Win!', width / 2, height / 2 - 20);
  textSize(24);
  text('Click to Restart', width / 2, height / 2 + 20);
}

// Draw the lose screen
function drawLoseScreen() {
  fill(255);
  textSize(32);
  textAlign(CENTER, CENTER);
  text('Game Over', width / 2, height / 2 - 20);
  textSize(24);
  text('Score: ' + score, width / 2, height / 2 + 10);
  text('Click to Restart', width / 2, height / 2 + 40);
}

// Main game function to handle gameplay
function playGame() {
  spaceship.display(); // Display the spaceship
  spaceship.move(); // Move the spaceship

  // Loop through each asteroid
  for (let i = asteroids.length - 1; i >= 0; i--) {
    asteroids[i].display(); // Display the asteroid
    asteroids[i].move(); // Move the asteroid

    // Check for collision between spaceship and asteroid
    if (spaceship.hits(asteroids[i])) {
      health -= 20; // Decrease health if hit
      createHitEffect(spaceship.x, spaceship.y); // Create hit effect
      if (health <= 0) {
        gameState = 'lose'; // Switch to lose state if health is 0 or less
      }
    }

    // Check for collision between bullets and asteroid
    for (let j = bullets.length - 1; j >= 0; j--) {
      if (bullets[j].hits(asteroids[i])) {
        createExplosion(asteroids[i].x, asteroids[i].y); // Create explosion
        asteroids.splice(i, 1); // Remove the asteroid
        bullets.splice(j, 1); // Remove the bullet
        score++; // Increase score
        break; // Exit the loop after collision
      }
    }
  }

  // Loop through each bullet
  for (let i = bullets.length - 1; i >= 0; i--) {
    bullets[i].display(); // Display the bullet
    bullets[i].move(); // Move the bullet

    // Remove the bullet if it goes offscreen
    if (bullets[i].offscreen()) {
      bullets.splice(i, 1);
    }
  }

  drawHealthMeter(); // Draw the health meter
  drawScore(); // Draw the score
  drawAmmo(); // Draw the ammo

  // Check if all asteroids are destroyed
  if (asteroids.length === 0) {
    gameState = 'win'; // Switch to win state if all asteroids are destroyed
  }
}

// Draw the health meter
function drawHealthMeter() {
  fill(255);
  rect(10, 10, 200, 20); // Background of health meter
  fill(0, 255, 0);
  rect(10, 10, health * 2, 20); // Green bar indicating health
  fill(255);
  textSize(12);
  text('Health', 10, 30); // Label for health meter
}

// Draw the player's score
function drawScore() {
  fill(255);
  textSize(24);
  textAlign(LEFT);
  text('Score: ' + score, 10, 60); // Display the score
}

// Draw the remaining ammo
function drawAmmo() {
  fill(255);
  textSize(24);
  textAlign(LEFT);
  text('Ammo: ' + ammo, 10, 90); // Display the ammo
}

// Create explosion effect
function createExplosion(x, y) {
  for (let i = 0; i < 50; i++) {
    particles.push(new Particle(x, y, 'explosion'));
  }
}

// Create hit effect for the spaceship
function createHitEffect(x, y) {
  for (let i = 0; i < 30; i++) {
    particles.push(new Particle(x, y, 'hit'));
  }
}

// Handle mouse click to start or restart the game
function mousePressed() {
  if (gameState === 'title' || gameState === 'win' || gameState === 'lose') {
    resetGame(); // Reset the game
    gameState = 'play'; // Switch to play state
  }
}

// Handle key press to shoot bullets
function keyPressed() {
  if (key === ' ' && ammo > 0) { // Check if space key is pressed and ammo is available
    bullets.push(new Bullet(spaceship.x, spaceship.y)); // Create a new bullet
    createSparkle(spaceship.x, spaceship.y); // Create sparkle effect
    ammo--; // Decrease ammo
  }
}

// Reset the game to initial state
function resetGame() {
  spaceship = new Spaceship(); // Reinitialize the spaceship
  asteroids = []; // Clear asteroids array
  for (let i = 0; i < numAsteroids; i++) {
    asteroids.push(new Asteroid()); // Create new asteroids
  }
  health = 100; // Reset health
  score = 0; // Reset score
  ammo = 50; // Reset ammo
}

// Spaceship class
class Spaceship {
  constructor() {
    this.x = width / 2; // Initial x position
    this.y = height / 2; // Initial y position
    this.r = 20; // Radius of spaceship
  }

  // Display the spaceship
  display() {
    fill(255);
    rectMode(CENTER);
    rect(this.x, this.y, this.r * 2, this.r * 2);
  }

  // Move the spaceship based on arrow keys
  move() {
    if (keyIsDown(LEFT_ARROW) && this.x > this.r) {
      this.x -= 5;
    }
    if (keyIsDown(RIGHT_ARROW) && this.x < width - this.r) {
      this.x += 5;
    }
    if (keyIsDown(UP_ARROW) && this.y > this.r) {
      this.y -= 5;
    }
    if (keyIsDown(DOWN_ARROW) && this.y < height - this.r) {
      this.y += 5;
    }
  }

  // Check for collision with an asteroid
  hits(asteroid) {
    let distance = dist(this.x, this.y, asteroid.x, asteroid.y);
    return distance < this.r + asteroid.r;
  }
}

// Bullet class
class Bullet {
  constructor(x, y) {
    this.x = x; // Initial x position
    this.y = y; // Initial y position
    this.r = 5; // Radius of bullet
  }

  // Display the bullet
  display() {
    fill(50, 200, 50);
    ellipse(this.x, this.y, this.r * 2);
  }

  // Move the bullet upwards
  move() {
    this.y -= 10;
  }

  // Check if the bullet is offscreen
  offscreen() {
    return this.y < 0;
  }

  // Check for collision with an asteroid
  hits(asteroid) {
    let distance = dist(this.x, this.y, asteroid.x, asteroid.y);
    return distance < this.r + asteroid.r;
  }
}

// Asteroid class
class Asteroid {
  constructor() {
    this.x = random(width); // Initial x position
    this.y = random(-100, -10); // Initial y position
    this.r = random(15, 50); // Radius of asteroid
    this.speed = random(1, 3); // Speed of asteroid
  }

  // Display the asteroid
  display() {
    fill(150);
    ellipse(this.x, this.y, this.r * 2);
  }

  // Move the asteroid downwards
  move() {
    this.y += this.speed;
    if (this.y > height) {
      this.y = random(-100, -10); // Reset position if offscreen
      this.x = random(width);
    }
  }
}

// Particle class
class Particle {
  constructor(x, y, type) {
    this.x = x;
    this.y = y;
    this.vx = random(-2, 2);
    this.vy = random(-2, 2);
    this.alpha = 255;
    this.type = type;
  }

  // Update particle position and fade out
  update() {
    this.x += this.vx;
    this.y += this.vy;
    this.alpha -= 5;
  }

  // Display the particle
  display() {
    if (this.type === 'explosion') {
      fill(255, 150, 0, this.alpha);
    } else if (this.type === 'hit') {
      fill(255, 0, 0, this.alpha);
    } else if (this.type === 'sparkle') {
      fill(50, 200, 50, this.alpha);
    }
    noStroke();
    ellipse(this.x, this.y, 10);
  }

  // Check if the particle is finished
  finished() {
    return this.alpha < 0;
  }
}

// Create sparkle effect when shooting
function createSparkle(x, y) {
  for (let i = 0; i < 10; i++) {
    particles.push(new Particle(x, y, 'sparkle'));
  }
}
