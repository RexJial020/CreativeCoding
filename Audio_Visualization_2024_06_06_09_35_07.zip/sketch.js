var mic, fft;
var sparkles = [];

function setup() {
  createCanvas(400, 400);
  
  mic = new p5.AudioIn(); 
  mic.start(); 
  
  fft = new p5.FFT(); 
  fft.setInput(mic);
}

function draw() {
  // Analyze the audio input
  var spectrum = fft.analyze();
  var amplitude = mic.getLevel();
  
  // If audio amplitude is high, create sparkles
  if (amplitude > 0.1) {
    for (var i = 0; i < 5; i++) { // Create multiple sparkles for a more intense effect
      var sparkle = {
        x: random(width),
        y: random(height),
        size: random(10, 30),
        color: color(random(200, 255), random(200, 255), random(200, 255), 200),
        trail: [] // Store fading trail
      };
      sparkles.push(sparkle);
    }
  }
  
  // Slowly fade the background to white
  fill(255, 50); // Adjust the alpha to control fading speed
  rect(0, 0, width, height);
  
  // Display sparkles
  for (var i = 0; i < sparkles.length; i++) {
    var s = sparkles[i];
    noStroke();
    fill(s.color);
    ellipse(s.x, s.y, s.size, s.size);
    
    // Create fading trail
    s.trail.push({ x: s.x, y: s.y, size: s.size });
    for (var j = 0; j < s.trail.length; j++) {
      var trailAlpha = map(j, 0, s.trail.length, 255, 0); // Fade out trail
      fill(red(s.color), green(s.color), blue(s.color), trailAlpha);
      ellipse(s.trail[j].x, s.trail[j].y, s.trail[j].size, s.trail[j].size);
    }
    
    // Move sparkles upward
    s.y -= random(1, 3);
    // Remove sparkles if they go out of canvas
    if (s.y < 0 || s.trail.length > 30) { // Limit trail length
      sparkles.splice(i, 1);
    }
  }
}
