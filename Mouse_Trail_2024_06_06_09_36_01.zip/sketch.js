function setup() {
    createCanvas(windowWidth, windowHeight);
    background(100); // Set the background color
}

// This function is triggered when the mouse is dragged
function mouseDragged () {
    // Generate random values for red, green, and blue components
    let r = random(0, 255);
    let g = random(0, 255);
    let b = random(0, 255);
    
    // Set the fill color using the random RGB values
    fill(r, g, b);
    
    // Draw a triangle at the current mouse position with a side length of 100
    triangle(mouseX, mouseY - 50,    // Top vertex
             mouseX - 50, mouseY + 50,  // Bottom-left vertex
             mouseX + 50, mouseY + 50); // Bottom-right vertex
}
