var word = "Welcome to Bath Spa University";

var font1, font2, font3;

function preload() {
  font1 = loadFont("ShadowsIntoLight.ttf");
  font2 = loadFont("Comfortaa-Light.ttf");
  font3 = loadFont("BlackOpsOne-Regular.ttf");

  
}

function setup() {
  createCanvas(600, 400);
  background(255, 165, 0);
  fill(0);

  // Using the first font
  textFont(font1, 40);
  textAlign(CENTER, CENTER);
  text(word, width / 2, height / 4);

  // Using the second font
  textFont(font2, 30);
  textAlign(LEFT, CENTER);
  text(word, 10, height / 2);

  // Using the third font
  textFont(font3, 35);
  textAlign(RIGHT, CENTER);
  text(word, width - 10, 3 * height / 4);

  // Mix the fonts in one line
  textAlign(CENTER, CENTER);
  for (let i = 0; i < word.length; i++) {
    let char = word.charAt(i);
    if (i % 3 == 0) {
      textFont(font1);
    } else if (i % 3 == 1) {
      textFont(font2);
    } else {
      textFont(font3);
    }
    text(char, width / 2 - 150 + i * 18, height - 50);
  }
}
