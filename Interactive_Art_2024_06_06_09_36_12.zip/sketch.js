let shapes = [];
let attractStrength = 0.3;
let repelStrength = -1.5;
let active = false;

function setup() {
  createCanvas(600, 400);
  
  // Create more initial shapes
  for (let i = 0; i < 100; i++) {
    let shape = new Shape(random(width), random(height));
    shapes.push(shape);
  }
}

function draw() {
  // Draw text as a background
  background(220);
  fill(0);
  textSize(20);
  textAlign(CENTER, CENTER);
  text("Click and hold to make the objects avoid the cursor and repel them", width / 2, height / 2);
  
  // Update and display each shape
  for (let shape of shapes) {
    if (active) {
      let repulsion = p5.Vector.sub(shape.pos, createVector(mouseX, mouseY));
      repulsion.setMag(repelStrength);
      shape.applyForce(repulsion);
    } else if (shape.avoidCursor) {
      let repulsion = p5.Vector.sub(shape.pos, createVector(mouseX, mouseY));
      repulsion.setMag(repelStrength);
      shape.applyForce(repulsion);
    }
    shape.update();
    shape.display();
  }
}

function mousePressed() {
  if (mouseButton === LEFT) {
    active = true;
    for (let shape of shapes) {
      shape.avoidCursor = true;
      shape.randomize();
    }
  }
}

function mouseReleased() {
  if (mouseButton === LEFT) {
    active = false;
    for (let shape of shapes) {
      shape.avoidCursor = false;
    }
  }
}

class Shape {
  constructor(x, y) {
    this.pos = createVector(x, y);
    this.vel = p5.Vector.random2D();
    this.acc = createVector();
    this.size = random(5, 15);
    this.color = color(random(255), random(255), random(255));
    this.avoidCursor = false; // Initial state to not avoid cursor
  }
  
  applyForce(force) {
    this.acc.add(force);
  }
  
  update() {
    // Update position, velocity, and reset acceleration
    this.vel.add(this.acc);
    this.vel.limit(3); // Limiting velocity to make shapes more active
    this.pos.add(this.vel);
    this.acc.mult(0);
    
    // Wrap around the canvas
    if (this.pos.x < 0) {
      this.pos.x = width;
    } else if (this.pos.x > width) {
      this.pos.x = 0;
    }
    if (this.pos.y < 0) {
      this.pos.y = height;
    } else if (this.pos.y > height) {
      this.pos.y = 0;
    }
  }
  
  display() {
    fill(this.color);
    noStroke();
    ellipse(this.pos.x, this.pos.y, this.size, this.size);
  }
  
  randomize() {
    this.pos.x = random(width);
    this.pos.y = random(height);
  }
}
