function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  
  // Body
  fill(100, 200, 100);
  ellipse(200, 200, 150, 200);
  
  // Arms
  strokeWeight(10);
  line(120, 200, 80, 250); // Left arm
  line(280, 200, 320, 250); // Right arm
  
  // Legs
  line(170, 300, 150, 350); // Left leg
  line(230, 300, 250, 350); // Right leg
  
  // Head
  fill(150, 250, 150);
  ellipse(200, 120, 100, 120);
  
  // Eyes
  fill(255);
  ellipse(175, 100, 20, 30); // Left eye
  ellipse(225, 100, 20, 30); // Right eye
  
  // Pupils
  fill(0);
  ellipse(175, 100, 10, 10); // Left pupil
  ellipse(225, 100, 10, 10); // Right pupil
  
  // Mouth
  noFill();
  strokeWeight(3);
  arc(200, 135, 50, 30, 0, PI);
  
  // Antennae
  stroke(0);
  strokeWeight(3);
  line(180, 70, 150, 40); // Left antennae
  line(220, 70, 250, 40); // Right antennae
  ellipse(150, 40, 10, 10); // Left antennae tip
  ellipse(250, 40, 10, 10); // Right antennae tip
}
