let table; // Variable to hold the CSV data

function preload() {
  // Load the CSV file
  table = loadTable('data.csv', 'csv', 'header');
}

function setup() {
  createCanvas(800, 600);
}

function draw() {
  background(255);
  
  // Check if data is loaded
  if (table) {
    let rowCount = table.getRowCount();
    let colCount = table.getColumnCount();
    let xOffset = width / (colCount + 1);
    
    for (let i = 0; i < rowCount; i++) {
      stroke(0);
      strokeWeight(2);
      beginShape();
      for (let j = 0; j < colCount; j++) {
        let x = xOffset * (j + 1);
        let y = height - 50;
        
        // Check if population data is available for the current year and country
        let population = table.getNum(i, j); // Assuming population is in numeric format
        if (!isNaN(population)) {
          y = map(population, 0, 1.5e9, height, 0);
        }
        
        vertex(x, y);
      }
      endShape();
    }
    
    // Draw axes and labels
    stroke(0);
    line(50, height - 50, width - 50, height - 50); // X-axis
    line(50, height - 50, 50, 50); // Y-axis
    
    fill(0);
    textSize(12);
    textAlign(CENTER);
    for (let j = 0; j < colCount; j++) {
      let x = xOffset * (j + 1);
      text(table.getString(0, j), x, height - 30); // Assuming the first row contains labels for years
    }
    
    rotate(-HALF_PI);
    text('Population (in billions)', -height / 2, 20);
    rotate(HALF_PI);
    text('Year', width / 2, height - 20);
  } else {
    // Display loading message
    fill(0);
    textSize(20);
    textAlign(CENTER, CENTER);
    text('Loading data...', width / 2, height / 2);
  }
}
